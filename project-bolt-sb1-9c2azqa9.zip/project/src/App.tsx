import { useState } from "react";
import { ArrowDown, ArrowUp } from "lucide-react";

export default function App() {
  const [balance, setBalance] = useState(1340.56);
  const [transactions, setTransactions] = useState([]);

  const handleTransaction = (type) => {
    const input = prompt(`Enter amount to ${type}`);
    const amount = parseFloat(input);
    if (isNaN(amount) || amount <= 0) return;

    const newBalance = type === "add" ? balance + amount : balance - amount;
    const newTransaction = {
      name: "You",
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      date: new Date().toDateString(),
      amount,
      type,
    };

    setBalance(newBalance);
    setTransactions([newTransaction, ...transactions]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-500 text-white font-sans px-4 py-6">
      <div className="max-w-md mx-auto">
        {/* Glass Wallet Card */}
        <div className="bg-white/10 backdrop-blur-md p-6 rounded-3xl shadow-xl mb-6">
          <h1 className="text-2xl font-semibold mb-1">My Wallet</h1>
          <p className="text-sm text-gray-200">Available Balance</p>
          <p className="text-4xl font-bold text-white mt-2">${balance.toFixed(2)}</p>

          <div className="flex gap-3 mt-5">
            <button
              onClick={() => handleTransaction("add")}
              className="flex-1 bg-green-400 hover:bg-green-500 transition-colors text-white py-2 rounded-xl shadow"
            >
              + Add Money
            </button>
            <button
              onClick={() => handleTransaction("withdraw")}
              className="flex-1 bg-red-400 hover:bg-red-500 transition-colors text-white py-2 rounded-xl shadow"
            >
              - Withdraw
            </button>
          </div>
        </div>

        {/* Transactions List */}
        <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl">
          <h2 className="text-xl font-semibold mb-3">Recent Transactions</h2>
          <div className="space-y-3 max-h-[300px] overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400/40">
            {transactions.length === 0 && (
              <p className="text-gray-300 text-sm">No transactions yet</p>
            )}
            {transactions.map((tx, index) => (
              <div
                key={index}
                className="flex justify-between items-center border-b border-white/10 pb-2"
              >
                <div>
                  <p className="font-medium text-white">{tx.name}</p>
                  <p className="text-xs text-gray-300">{tx.date}, {tx.time}</p>
                </div>
                <div className="flex items-center gap-2">
                  {tx.type === "withdraw" ? (
                    <ArrowUp className="text-red-400 w-4 h-4" />
                  ) : (
                    <ArrowDown className="text-green-400 w-4 h-4" />
                  )}
                  <p
                    className={`text-lg font-semibold ${
                      tx.type === "withdraw" ? "text-red-400" : "text-green-400"
                    }`}
                  >
                    ${tx.amount}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Continue Button */}
        <button className="mt-6 w-full bg-white/10 hover:bg-white/20 backdrop-blur-md text-white py-3 rounded-2xl text-lg font-semibold transition-all">
          Continue
        </button>
      </div>
    </div>
  );
}